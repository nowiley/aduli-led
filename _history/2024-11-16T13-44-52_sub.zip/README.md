# aduli-led

Auto-calibrating Display using Unconstrained Layouts of Individually-addressable LEDs
