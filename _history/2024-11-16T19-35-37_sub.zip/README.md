# aduli-led

Auto-calibrating Display using Unconstrained Layouts of Individually-addressable LEDs

### Useful commands:

#### Build on Vivado farm

```
lab-bc run ./ obj
```

#### Flash to FPGA

```
openFPGALoader -b arty_s7_50 obj/final.bit
```
